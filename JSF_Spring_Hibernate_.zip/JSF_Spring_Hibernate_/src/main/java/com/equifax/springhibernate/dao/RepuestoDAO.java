package com.equifax.springhibernate.dao;

import java.util.List;

import com.equifax.springhibernate.model.Repuesto;
 
public interface RepuestoDAO {
 
    public void addRepuesto(Repuesto p);
    public List<Repuesto> listRepuestos();
    public void deleteRepuesto(Repuesto p);
}
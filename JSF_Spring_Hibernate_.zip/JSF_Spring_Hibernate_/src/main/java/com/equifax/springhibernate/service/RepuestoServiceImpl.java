package com.equifax.springhibernate.service;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.equifax.springhibernate.dao.RepuestoDAO;
import com.equifax.springhibernate.model.Repuesto;

@Service //hace rol controlador que administra la petición del Faces Servlet dada por las acciones respectivas en el .xhtml
//@ManagedBean(name="repuestoService")
//@SessionScoped
public class RepuestoServiceImpl implements RepuestoService {

	private RepuestoDAO repuestoDAO;
	 
    public void setRepuestoDAO(RepuestoDAO repuestoDAO) {
        this.repuestoDAO = repuestoDAO;
    }
 
    @Override
    @Transactional
    public void addRepuesto(Repuesto p) {
        this.repuestoDAO.addRepuesto(p);
    }
 
    @Override
    @Transactional
    public List<Repuesto> listRepuestos() {
        return this.repuestoDAO.listRepuestos();
    }

	@Override
	@Transactional
	public void deleteRepuesto(Repuesto p) {
		this.repuestoDAO.deleteRepuesto(p);		
	}
 
}

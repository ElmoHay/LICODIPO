package com.equifax.springhibernate.service;

import java.util.List;

import com.equifax.springhibernate.model.Repuesto;
 
public interface RepuestoService {
 
    public void addRepuesto(Repuesto p);
    public List<Repuesto> listRepuestos();
    public void deleteRepuesto(Repuesto p); 
}